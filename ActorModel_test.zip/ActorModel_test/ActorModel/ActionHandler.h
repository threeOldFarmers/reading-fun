//
//  ActionHandler.h
//  ActorModel
//
//  Created by hanguang on 2020/5/20.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol Subscriber;

@interface ActionHandler : NSObject

@property (nonatomic, weak) id<Subscriber> subscriber;
@property (nonatomic) bool shouldReleaseOnMainQueue;

- (instancetype)initWithSubscriber:(id<Subscriber>)subscriber;
- (instancetype)initWithSubscriber:(id<Subscriber>)subscriber shouldReleaseOnMainQueue:(bool)shouldReleaseOnMainQueue;

- (void)reset;
- (bool)isHaveSubscriber;

- (void)notifyActionReceived:(NSString *)action options:(NSDictionary *)options;
- (void)notifyMessageReceived:(NSString *)path message:(id)message type:(NSString *)type;
- (void)notifyResourceReceived:(NSString *)path resource:(id)resource options:(NSDictionary *)options;

@end
