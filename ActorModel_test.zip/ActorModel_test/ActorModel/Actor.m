//
//  GHActor.m
//  ActorModel
//
//  Created by hanguang on 2020/5/21.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import "Actor.h"
#import "Cancellable.h"

static NSMutableDictionary *registeredActorClasses() {
    static NSMutableDictionary *dict = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dict = [[NSMutableDictionary alloc] init];
    });
    return dict;
}

@implementation Actor

+ (void)registerActor:(Class)actorClass {
    NSString *genericPath = [actorClass genericPath];
    if (genericPath == nil || genericPath.length == 0) {
        NSLog(@"[ActorModel] Error: GHActor::registerActor genericPath is nil");
        return;
    }
    
    registeredActorClasses()[genericPath] = actorClass;
}

+ (Actor *)actorClassForGenericPath:(NSString *)genericPath path:(NSString *)path {
    Class actorClass = registeredActorClasses()[genericPath];
    if (actorClass != nil) {
        Actor *instance = [[actorClass alloc] initWithPath:path];
        return instance;
    }
    return nil;
}

+ (NSString *)genericPath {
    @throw [NSException exceptionWithName:@"[ActorModel]" reason:@"Error: GHActor::genericPath: subclass needs to implement" userInfo:nil];
    return nil;
}

- (instancetype)initWithPath:(NSString *)path {
    self = [super init];
    if (self) {
        _timeout = 0;
        _path = path;
    }
    return self;
}

- (void)prepare:(NSDictionary *)options {}

- (void)execute:(NSDictionary *)options {
    @throw [NSException exceptionWithName:@"[ActorModel]" reason:@"Error: GHActor::execute: subclass needs to implement" userInfo:nil];
}

- (void)cancel {
    if (_cancelToken != nil) {
        [_cancelToken cancel];
        _cancelToken = nil;
    }
    
    if (_cancelTokenArray.count) {
        for (id<Cancellable> token in _cancelTokenArray) {
            [token cancel];
        }
        _cancelTokenArray = nil;
    }
    
    _cancelled = true;
}

- (void)addCancelToken:(id<Cancellable>)token {
    if (_cancelTokenArray == nil) {
        _cancelTokenArray = [NSMutableArray new];
    }
    [_cancelTokenArray addObject:token];
}

- (void)newSubscriberJoined:(ActionHandler *)actionHandler options:(NSDictionary *)options alreadyInQueue:(bool)waitingInActorQueue {}

@end
