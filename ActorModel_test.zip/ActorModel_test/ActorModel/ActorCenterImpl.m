//
//  GHActor.m
//  ActorModel
//
//  Created by hanguang on 2020/5/20.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import "ActorCenterImpl.h"
#import "os/lock.h"
#import "CustomTimer.h"

#define kTimer @"timer"
#define kRequestInfo @"requestInfo"
#define kRequestActor @"requestActor"
#define kSubscribers @"subscribers"
#define kPath @"path"

static const char *actorQueueSpecific = "com.actormodel.dispatchqueue";

static dispatch_queue_t mainActorQueue = nil;
static dispatch_queue_t globalActorQueue = nil;
static dispatch_queue_t highPriorityActorQueue = nil;

static os_unfair_lock removeSubscriberRequestsLock = OS_UNFAIR_LOCK_INIT;
static os_unfair_lock removeSubscriberFromPathRequestsLock = OS_UNFAIR_LOCK_INIT;

@interface RequestData : NSObject

@property (nonatomic, strong) ActionHandler *handler;
@property (nonatomic, strong) NSString *path;

@end

@implementation RequestData

@end

@interface ActorCenterImpl ()

@property (nonatomic, strong) NSMutableArray <RequestData *> *removeSubscriberFromPathRequests;
@property (nonatomic, strong) NSMutableArray <ActionHandler *> *removeSubscriberRequests;
@property (nonatomic, strong) NSMutableDictionary *requestQueues;
@property (nonatomic, strong) NSMutableDictionary *activeRequests;
@property (nonatomic, strong) NSMutableDictionary *cancelRequestTimers;
@property (nonatomic, strong) NSMutableDictionary *liveSubscribers;

@end

ActorCenterImpl *ActorCenter(void) {
    static ActorCenterImpl *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[ActorCenterImpl alloc] init];
    });
    return instance;
}

@implementation ActorCenterImpl

- (instancetype)init {
    self = [super init];
    if (self != nil) {
        _requestQueues = [[NSMutableDictionary alloc] init];
        _activeRequests = [[NSMutableDictionary alloc] init];
        _cancelRequestTimers = [[NSMutableDictionary alloc] init];
        _liveSubscribers = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (dispatch_queue_t)serialActorDispatchQueue {
    if (mainActorQueue == NULL) {
        mainActorQueue = dispatch_queue_create("com.actormodel.dispatchqueue", 0);
        globalActorQueue = dispatch_queue_create("com.actormodel.dispatchqueue-global", 0);
        dispatch_set_target_queue(globalActorQueue, mainActorQueue);
        highPriorityActorQueue = dispatch_queue_create("com.actormodel.dispatchqueue-high", 0);
        dispatch_set_target_queue(highPriorityActorQueue, mainActorQueue);
        dispatch_queue_set_specific(mainActorQueue, actorQueueSpecific, (void *)actorQueueSpecific, NULL);
        dispatch_queue_set_specific(globalActorQueue, actorQueueSpecific, (void *)actorQueueSpecific, NULL);
        dispatch_queue_set_specific(highPriorityActorQueue, actorQueueSpecific, (void *)actorQueueSpecific, NULL);
    }
    return globalActorQueue;
}

- (bool)isActorDispatchQueue {
    return dispatch_get_specific(actorQueueSpecific) != NULL;
}

#ifdef DEBUG
- (void)dispatchOnActorQueueDebug:(const char *)function line:(int)line block:(dispatch_block_t)block
#else
- (void)dispatchOnActorQueue:(dispatch_block_t)block
#endif
{
    bool isActorQueue = [self isActorDispatchQueue];
    
    if (isActorQueue) {
#ifdef DEBUG
        CFAbsoluteTime startTime = CFAbsoluteTimeGetCurrent();
#endif
        block();
#ifdef DEBUG
        CFAbsoluteTime executionTime = (CFAbsoluteTimeGetCurrent() - startTime);
        if (executionTime > 0.1) {
            NSLog(@"[ActorModel] $$$ Dispatch from %s:%d took %f s", function, line, executionTime);
        }
#endif
    } else {
#ifdef DEBUG
        dispatch_async([self serialActorDispatchQueue], ^{
            CFAbsoluteTime startTime = CFAbsoluteTimeGetCurrent();
            
            block();
            
            CFAbsoluteTime executionTime = (CFAbsoluteTimeGetCurrent() - startTime);
            if (executionTime > 0.1) {
                NSLog(@"[ActorModel] $$$ Dispatch from %s:%d took %f s", function, line, executionTime);
            }
        });
#else
        dispatch_async([self globalActorDispatchQueue], block);
#endif
    }
}

- (void)dispatchOnHighPriorityQueue:(dispatch_block_t)block {
    if ([self isActorDispatchQueue]) {
        block();
    } else {
        if (highPriorityActorQueue == NULL) {
            [self serialActorDispatchQueue];
        }
        dispatch_async(highPriorityActorQueue, block);
    }
}

- (void)showActorCenterStatus {
    [self dispatchOnActorQueue:^{
        NSLog(@"===== ActorCenterStatus =====");
        NSLog(@"%ld subscribers", self.liveSubscribers.count);
        [self.liveSubscribers enumerateKeysAndObjectsUsingBlock:^(NSString *path, NSArray *subscribers, __unused BOOL *stop) {
            NSLog(@"    %@", path);
            for (ActionHandler *handler in subscribers) {
                id<Subscriber> subscriber = handler.subscriber;
                if (subscriber != nil) {
                    NSLog(@"        %@", [subscriber description]);
                }
            }
        }];
        NSLog(@"%ld Actors executing", self.activeRequests.count);
        [self.activeRequests enumerateKeysAndObjectsUsingBlock:^(NSString *path, __unused id obj, __unused BOOL *stop) {
            NSLog(@"        %@", path);
        }];
        NSLog(@"========================");
    }];
}

- (NSString *)generateGenericPathForPath:(NSString *)path {
    if (path.length == 0) {
        return @"";
    }
    
    int length = (int)path.length;
    unichar newPath[path.length];
    
    bool skip = false;
    bool skippedCharacters = false;
    int index = 0;
    
    for (int i = 0; i < length; i++) {
        unichar c = [path characterAtIndex:i];
        if (c == PathParameterStartSymbol) {
            skip = true;
            skippedCharacters = true;
            newPath[index++] = PathParameterSymbol;
        } else if (c == PathParameterEndSymbol) {
            skip = false;
        } else if (!skip) {
            newPath[index++] = c;
        }
    }

    if (!skippedCharacters) {
        return path;
    }
    
    NSString *genericPath = [[NSString alloc] initWithCharacters:newPath length:index];
    return genericPath;
}

- (void)requestGeneric:(bool)joinOnly inCurrentQueue:(bool)inCurrentQueue path:(NSString *)path options:(NSDictionary *)options flags:(int)flags subscriber:(id<Subscriber>)subscriber {
    ActionHandler *actionHandler = subscriber.handler;
    dispatch_block_t requestBlock = ^{
        if (![actionHandler isHaveSubscriber]) {
            NSLog(@"[ActorModel] Error: %s:%d: actionHandler.subscriber is nil", __PRETTY_FUNCTION__, __LINE__);
            return;
        }
        
        NSMutableDictionary *activeRequests = self.activeRequests;
        NSMutableDictionary *cancelTimers = self.cancelRequestTimers;

        NSString *genericPath = [self generateGenericPathForPath:path];

        NSMutableDictionary *requestInfo = nil;

        NSMutableDictionary *cancelRequestInfo = cancelTimers[path];
        if (cancelRequestInfo != nil) {
            CustomTimer *timer = cancelRequestInfo[kTimer];
            [timer cancel];
            timer = nil;
            requestInfo = cancelRequestInfo[kRequestInfo];
            activeRequests[path] = requestInfo;
            [cancelTimers removeObjectForKey:path];
            NSLog(@"[ActorModel] Resuming request to \"%@\"", path);
        }

        if (requestInfo == nil) {
            requestInfo = activeRequests[path];
        }
        
        if (joinOnly && requestInfo == nil) {
            return;
        }
        
        if (requestInfo == nil) {
            Actor *requestActor = [Actor actorClassForGenericPath:genericPath path:path];
            if (requestActor != nil) {
                NSMutableArray *subscribers = [[NSMutableArray alloc] initWithObjects:actionHandler, nil];
                
                requestInfo = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                               requestActor, kRequestActor,
                               subscribers, kSubscribers,
                               nil];
                
                activeRequests[path] = requestInfo;
                
                [requestActor prepare:options];
                
                bool executeNow = true;
                if (requestActor.queue != nil) {
                    NSMutableArray *requestQueue = self.requestQueues[requestActor.queue];
                    if (requestQueue == nil) {
                        requestQueue = [[NSMutableArray alloc] initWithArray:@[requestActor]];
                        self.requestQueues[requestActor.queue] = requestQueue;
                    } else {
                        [requestQueue addObject:requestActor];
                        if ([requestQueue count] > 1) {
                            executeNow = false;
                            NSLog(@"[ActorModel] Adding request %@ to request queue \"%@\"", requestActor, requestActor.queue);
                        }
                    }
                }
                
                if (executeNow) {
                    [requestActor execute:options];
                } else {
                    requestActor.storedOptions = options;
                }
            } else {
                NSLog(@"[ActorModel] Error: request actor not found for \"%@\"", path);
            }
        } else {
            NSMutableArray *subscribers = requestInfo[kSubscribers];
            if (![subscribers containsObject:actionHandler]) {
                NSLog(@"[ActorModel] Joining subscriber to the subscribers of \"%@\"", path);
                [subscribers addObject:actionHandler];
            } else {
                NSLog(@"[ActorModel] Continue to watch for actor \"%@\"", path);
            }
            
            Actor *actor = requestInfo[kRequestActor];
            if (actor.queue == nil) {
                [actor newSubscriberJoined:actionHandler options:options alreadyInQueue:false];
            } else {
                NSMutableArray *requestQueue = self.requestQueues[actor.queue];
                if (requestQueue == nil || requestQueue.count == 0) {
                    [actor newSubscriberJoined:actionHandler options:options alreadyInQueue:false];
                } else {
                    [actor newSubscriberJoined:actionHandler options:options alreadyInQueue:[requestQueue objectAtIndex:0] != actor];
                }
            }
        }
    };
    
    if (inCurrentQueue) {
        requestBlock();
    } else {
        [self dispatchOnActorQueue:requestBlock];
    }
}

- (NSArray *)reSubscribeGenericPathForActorsNow:(NSString *)genericPath prefix:(NSString *)prefix subscriber:(id<Subscriber>)subscriber {
    NSMutableDictionary *activeRequests = _activeRequests;
    NSMutableDictionary *cancelTimers = _cancelRequestTimers;
    
    NSMutableArray *rejoinPaths = [NSMutableArray new];
    
    for (NSString *path in activeRequests.allKeys) {
        if ([path isEqualToString:genericPath] || ([[self generateGenericPathForPath:path] isEqualToString:genericPath] && (prefix.length == 0 || [path hasPrefix:prefix]))) {
            [rejoinPaths addObject:path];
        }
    }
    
    for (NSString *path in cancelTimers.allKeys) {
        if ([[self generateGenericPathForPath:path] isEqualToString:genericPath] && [path hasPrefix:prefix]) {
            [rejoinPaths addObject:path];
        }
    }
    
    for (NSString *path in rejoinPaths) {
        [self requestGeneric:true inCurrentQueue:true path:path options:nil flags:0 subscriber:subscriber];
    }
    
    return rejoinPaths;
}

- (bool)isActorExecutingForGenericPath:(NSString *)genericPath {
    if (![self isActorDispatchQueue]) {
        NSLog(@"[ActorModel] %s should be called from actor queue", __PRETTY_FUNCTION__);
        return nil;
    }
    
    __block bool result = false;
    
    [_activeRequests enumerateKeysAndObjectsUsingBlock:^(__unused NSString *path, NSDictionary *actorInfo, BOOL *stop) {
        Actor *actor = actorInfo[kRequestActor];
        
        if ([genericPath isEqualToString:[actor.class genericPath]]) {
            result = true;
            if (stop != NULL) {
                *stop = true;
            }
        }
    }];
    
    if (!result) {
        [_cancelRequestTimers enumerateKeysAndObjectsUsingBlock:^(__unused NSString *path, NSDictionary *actorInfo, BOOL *stop) {
            Actor *actor = actorInfo[kRequestActor];
            
            if ([genericPath isEqualToString:[actor.class genericPath]]) {
                result = true;
                if (stop != NULL) {
                    *stop = true;
                }
            }
        }];
    }
    
    return result;
}

- (bool)isActorExecutingForPathPrefix:(NSString *)prefix {
    if (![self isActorDispatchQueue]) {
        NSLog(@"[ActorModel] %s should be called from actor queue", __PRETTY_FUNCTION__);
        return nil;
    }

    __block bool result = false;

    [_activeRequests enumerateKeysAndObjectsUsingBlock:^(NSString *path, __unused id obj, BOOL *stop) {
        if ([path hasPrefix:prefix]) {
            result = true;
            if (stop != NULL) {
                *stop = true;
            }
        }
    }];

    if (!result) {
        [_cancelRequestTimers enumerateKeysAndObjectsUsingBlock:^(NSString *path, __unused id obj, BOOL *stop) {
            if ([path hasPrefix:prefix]) {
                result = true;
                if (stop != NULL) {
                    *stop = true;
                }
            }
        }];
    }

    return result;
}

- (NSArray *)executingActorsForPathPrefix:(NSString *)prefix {
    if (![self isActorDispatchQueue]) {
        NSLog(@"[ActorModel] %s should be called from actor queue", __PRETTY_FUNCTION__);
        return nil;
    }
    
    NSMutableArray *array = [NSMutableArray new];
    
    [_activeRequests enumerateKeysAndObjectsUsingBlock:^(NSString *path, NSDictionary *actorInfo, __unused BOOL *stop) {
        if ([path hasPrefix:prefix]) {
            Actor *actor = actorInfo[kRequestActor];
            if (actor != nil) {
                [array addObject:actor];
            }
        }
    }];
    
    [_cancelRequestTimers enumerateKeysAndObjectsUsingBlock:^(NSString *path, NSDictionary *actorInfo, __unused BOOL *stop) {
        if ([path hasPrefix:prefix]) {
            Actor *actor = actorInfo[kRequestActor];
            if (actor != nil) {
                [array addObject:actor];
            }
        }
    }];
    
    return array;
}

- (Actor *)executingActorForPath:(NSString *)path {
    if (![self isActorDispatchQueue]) {
        NSLog(@"[ActorModel] %s should be called from actor queue", __PRETTY_FUNCTION__);
        return nil;
    }
    
    NSMutableDictionary *requestInfo = _activeRequests[path];
    if (requestInfo != nil) {
        Actor *requestActor = requestInfo[kRequestActor];
        return requestActor;
    }
    
    NSMutableDictionary *cancelRequestInfo = _cancelRequestTimers[path];
    if (cancelRequestInfo != nil) {
        Actor *requestActor = cancelRequestInfo[kRequestInfo][kRequestActor];
        return requestActor;
    }
    
    return nil;
}

- (void)cancelAllTimeoutActorForPath:(NSString *)path {
    NSMutableDictionary *cancelRequestInfo = _cancelRequestTimers[path];
    if (cancelRequestInfo != nil) {
        CustomTimer *timer = cancelRequestInfo[kTimer];
        [timer startThenInvalid];
        timer = nil;
    }
}

- (void)requestActor:(NSString *)path options:(NSDictionary *)options subscriber:(id<Subscriber>)subscriber {
    [self requestGeneric:false inCurrentQueue:false path:path options:options flags:0 subscriber:subscriber];
}

- (void)requestActor:(NSString *)path options:(NSDictionary *)options subscriber:(id<Subscriber>)subscriber flags:(int)flags {
    [self requestGeneric:false inCurrentQueue:false path:path options:options flags:flags subscriber:subscriber];
}

- (void)subscribePath:(NSString *)path subscriber:(id<Subscriber>)subscriber {
    ActionHandler *actionHandler = subscriber.handler;
    if (actionHandler == nil) {
        NSLog(@"[ActorModel] Warning: actionHandler is nil in %s:%d", __PRETTY_FUNCTION__, __LINE__);
        return;
    }
    
    [self dispatchOnActorQueue:^{
        NSMutableArray *subscribers = self.liveSubscribers[path];
        if (subscribers == nil) {
            subscribers = [NSMutableArray new];
            self.liveSubscribers[path] = subscribers;
        }
        
        if (![subscribers containsObject:actionHandler]) {
            [subscribers addObject:actionHandler];
        }
    }];
}

- (void)subscribePaths:(NSArray *)paths subscriber:(id<Subscriber>)subscriber {
    ActionHandler *actionHandler = subscriber.handler;
    if (actionHandler == nil) {
        NSLog(@"[ActorModel] Warning: actionHandler is nil in %s:%d", __PRETTY_FUNCTION__, __LINE__);
        return;
    }
    
    [self dispatchOnActorQueue:^{
        for (NSString *path in paths) {
            NSMutableArray *subscribers = self.liveSubscribers[path];
            if (subscribers == nil) {
                subscribers = [NSMutableArray new];
                self.liveSubscribers[path] = subscribers;
            }
            
            if (![subscribers containsObject:actionHandler]) {
                [subscribers addObject:actionHandler];
            }
        }
    }];
}

- (void)subscribePath的genericPath:(NSString *)path subscriber:(id<Subscriber>)subscriber {
    ActionHandler *actionHandler = subscriber.handler;
    if (actionHandler == nil) {
        NSLog(@"[ActorModel] Warning: actionHandler is nil in %s:%d", __PRETTY_FUNCTION__, __LINE__);
        return;
    }
    
    [self dispatchOnActorQueue:^{
        NSString *genericPath = [self generateGenericPathForPath:path];
        NSMutableArray *subscribers = self.liveSubscribers[genericPath];
        if (subscribers == nil) {
            subscribers = [NSMutableArray new];
            self.liveSubscribers[genericPath] = subscribers;
        }
        
        if (![subscribers containsObject:actionHandler]) {
            [subscribers addObject:actionHandler];
        }
    }];
}

- (void)removeRequestActorFromQueue:(NSString *)path fromRequestActor:(Actor *)requestActor {
    NSMutableArray *requestQueue = _requestQueues[requestActor.queue == nil ? path : requestActor.queue];
    if (requestQueue == nil) {
        NSLog(@"[ActorModel] Warning: requestQueue is nil");
    } else {
        if (requestQueue.count == 0) {
            NSLog(@"[ActorModel] Warning: request queue \"%@\" is empty.", requestActor.queue);
        } else {
            if ([requestQueue objectAtIndex:0] == requestActor) {
                [requestQueue removeObjectAtIndex:0];
                
                if (requestQueue.count != 0) {
                    Actor *nextRequest = nil;
                    id nextRequestOptions = nil;
                    
                    nextRequest = [requestQueue objectAtIndex:0];
                    nextRequestOptions = nextRequest.storedOptions;
                    nextRequest.storedOptions = nil;
                    
                    if (nextRequest != nil && !nextRequest.cancelled)
                        [nextRequest execute:nextRequestOptions];
                } else {
                    [_requestQueues removeObjectForKey:requestActor.queue];
                }
            } else {
                if ([requestQueue containsObject:requestActor]) {
                    [requestQueue removeObject:requestActor];
                } else {
                    NSLog(@"[ActorModel] Warning: request queue \"%@\" doesn't contain request to %@", requestActor.queue, requestActor.path);
                }
            }
        }
    }
}

- (void)removeSubscriber:(id<Subscriber>)subscriber {
    [self removeSubscriberByHandler:subscriber.handler];
}

- (void)removeSubscriberByHandler:(ActionHandler *)handler {
    ActionHandler *actionHandler = handler;
    if (actionHandler == nil) {
        NSLog(@"[ActorModel] Warning: actor handle is nil in removeSubscriber");
        return;
    }
    
    bool alreadyExecuting = false;
    os_unfair_lock_lock(&removeSubscriberRequestsLock);
    if (_removeSubscriberRequests.count > 0) {
        alreadyExecuting = true;
    }
    [_removeSubscriberRequests addObject:actionHandler];
    os_unfair_lock_unlock(&removeSubscriberRequestsLock);
    
    if (alreadyExecuting && ![self isActorDispatchQueue]) {
        return;
    }
    
    [self dispatchOnHighPriorityQueue:^{
        NSMutableArray *removeSubscribers = [NSMutableArray new];
        
        os_unfair_lock_lock(&removeSubscriberRequestsLock);
        [removeSubscribers addObjectsFromArray:self.removeSubscriberRequests];
        [self.removeSubscriberRequests removeAllObjects];
        os_unfair_lock_unlock(&removeSubscriberRequestsLock);
        
        for (ActionHandler *actionHandler in removeSubscribers) {
            for (id key in [self.activeRequests allKeys]) {
                NSMutableDictionary *requestInfo = self.activeRequests[key];
                NSMutableArray *subscribers = requestInfo[kSubscribers];
                [subscribers removeObject:actionHandler];
                
                if (subscribers.count == 0) {
                    [self scheduleCancelRequest:(NSString *)key];
                }
            }
            
            NSMutableArray *keysToRemove = nil;
            for (NSString *key in [self.liveSubscribers allKeys]) {
                NSMutableArray *subscribers = self.liveSubscribers[key];
                [subscribers removeObject:actionHandler];
                
                if (subscribers.count == 0) {
                    if (keysToRemove == nil) {
                        keysToRemove = [NSMutableArray new];
                    }
                    [keysToRemove addObject:key];
                }
            }
            
            if (keysToRemove != nil) {
                [self.liveSubscribers removeObjectsForKeys:keysToRemove];
            }
        }
    }];
}

- (void)removeAllSubscriberForPath:(NSString *)path {
    [self dispatchOnHighPriorityQueue:^{
        NSMutableDictionary *requestInfo = self.activeRequests[path];
        if (requestInfo != nil) {
            NSMutableArray *subscribers = requestInfo[kSubscribers];
            [subscribers removeAllObjects];
            [self scheduleCancelRequest:path];
        }
    }];
}

- (void)removeSubscriber:(id<Subscriber>)subscriber forPath:(NSString *)path {
    ActionHandler *actionHandler = subscriber.handler;
    [self removeSubscriberByHandler:actionHandler forPath:path];
}

- (void)removeSubscriberByHandler:(ActionHandler *)actionHandler forPath:(NSString *)path {
    if (actionHandler == nil) {
        NSLog(@"[ActorModel] Warning: actor handle is nil in removeSubscriber:fromPath");
        return;
    }
    
    bool alreadyExecuting = false;
    os_unfair_lock_lock(&removeSubscriberFromPathRequestsLock);
    if (_removeSubscriberFromPathRequests.count > 0) {
        alreadyExecuting = true;
    }
    RequestData *data = [RequestData new];
    data.handler = actionHandler;
    data.path = path;
    [_removeSubscriberFromPathRequests addObject:data];
    os_unfair_lock_unlock(&removeSubscriberFromPathRequestsLock);
    
    if (alreadyExecuting && ![self isActorDispatchQueue]) {
        return;
    }
    
    [self dispatchOnHighPriorityQueue:^{
        NSMutableArray *removeSubscribersFromPath = [NSMutableArray new];
        
        os_unfair_lock_lock(&removeSubscriberFromPathRequestsLock);
        [removeSubscribersFromPath addObjectsFromArray:self.removeSubscriberFromPathRequests];
        [self.removeSubscriberFromPathRequests removeAllObjects];
        os_unfair_lock_unlock(&removeSubscriberFromPathRequestsLock);
        
        if (removeSubscribersFromPath.count > 1) {
            NSLog(@"[ActorModel] Cancelled %ld requests at once", removeSubscribersFromPath.count);
        }
        
        for (RequestData *data in removeSubscribersFromPath) {
            ActionHandler *actionHandler = data.handler;
            NSString *path = data.path;
            if (path == nil) {
                continue;
            }
            
            // active requests
            {
                NSMutableDictionary *requestInfo = self.activeRequests[path];
                if (requestInfo != nil) {
                    NSMutableArray *subscribers = requestInfo[kSubscribers];
                    if ([subscribers containsObject:actionHandler]) {
                        [subscribers removeObject:actionHandler];
                    }
                    if (subscribers.count == 0) {
                        [self scheduleCancelRequest:(NSString *)path];
                    }
                }
            }
            
            // live subscribers
            {
                NSMutableArray *subscribers = self.liveSubscribers[path];
                if ([subscribers containsObject:actionHandler]) {
                    [subscribers removeObject:actionHandler];
                }
                if (subscribers.count == 0) {
                    [self.liveSubscribers removeObjectForKey:path];
                }
            }
        }
    }];
}

- (bool)isActorExecutingForPath:(NSString *)path {
    if (_activeRequests[path] != nil) {
        return true;
    }
    return false;
}

- (void)dispatchToPath:(NSString *)path resource:(id)resource {
    [self dispatchToPath:path resource:resource options:nil];
}

- (void)dispatchToPath:(NSString *)path resource:(id)resource options:(NSDictionary *)options {
    [self dispatchOnActorQueue:^{
        NSString *genericPath = [self generateGenericPathForPath:path];
        NSArray *subscribers = [self.liveSubscribers[path] copy];
        if (subscribers != nil) {
            for (ActionHandler *handler in subscribers) {
                id<Subscriber> subscriber = handler.subscriber;
                if (subscriber != nil) {
                    if ([subscriber respondsToSelector:@selector(receivePath:resource:options:)]) {
                        [subscriber receivePath:path resource:resource options:options];
                    }
                    
                    if (handler.shouldReleaseOnMainQueue) {
                        dispatch_async(dispatch_get_main_queue(), ^{ [subscriber class]; });
                    }
                    subscriber = nil;
                }
            }
        }
        
        if (![genericPath isEqualToString:path]) {
            NSArray *subscribers = self.liveSubscribers[genericPath];
            if (subscribers != nil) {
                for (ActionHandler *handler in subscribers) {
                    id<Subscriber> subscriber = handler.subscriber;
                    if (subscriber != nil) {
                        if ([subscriber respondsToSelector:@selector(receivePath:resource:options:)]) {
                            [subscriber receivePath:path resource:resource options:options];
                        }
                        
                        if (handler.shouldReleaseOnMainQueue) {
                            dispatch_async(dispatch_get_main_queue(), ^{ [subscriber class]; });
                        }
                        subscriber = nil;
                    }
                }
            }
        }
    }];
}

- (void)actorComplete:(NSString *)path result:(id)result {
    [self dispatchOnActorQueue:^{
        NSMutableDictionary *requestInfo = self.activeRequests[path];
        if (requestInfo != nil) {
            Actor *requestActor = requestInfo[kRequestActor];
            
            NSMutableArray *subscribers = requestInfo[kSubscribers];
            [self.activeRequests removeObjectForKey:path];
            for (ActionHandler *handler in subscribers) {
                id<Subscriber> subscriber = handler.subscriber;
                if (subscriber != nil) {
                    if ([subscriber respondsToSelector:@selector(actorComplete:status:result:)]) {
                        [subscriber actorComplete:path status:ActorResultSuccess result:result];
                    }
                    
                    if (handler.shouldReleaseOnMainQueue) {
                        dispatch_async(dispatch_get_main_queue(), ^{ [subscriber class]; });
                    }
                    subscriber = nil;
                }
            }
            [subscribers removeAllObjects];
            
            if (requestActor == nil) {
                NSLog(@"[ActorModel] Warning ***** requestActor is nil");
            } else if (requestActor.queue != nil) {
                [self removeRequestActorFromQueue:requestActor.queue fromRequestActor:requestActor];
            }
        }
    }];
}

- (void)dispatchToExecutingActors:(NSString *)path message:(id)message type:(NSString *)type {
    [self dispatchOnActorQueue:^{
        NSMutableDictionary *requestInfo = self.activeRequests[path];
        if (requestInfo != nil) {
            NSArray *subscribersCopy = [requestInfo[kSubscribers] copy];
            for (ActionHandler *handler in subscribersCopy) {
                [handler notifyMessageReceived:path message:message type:type];
            }
        }
    }];
}

- (void)dispatchToSubscriberPath:(NSString *)path message:(id)message type:(NSString *)type {
    [self dispatchOnActorQueue:^{
        NSString *genericPath = [self generateGenericPathForPath:path];
        NSArray *handlers = self.liveSubscribers[genericPath];
        for (ActionHandler *handler in handlers) {
            if ([handler respondsToSelector:@selector(notifyMessageReceived:message:type:)]) {
                [handler notifyMessageReceived:path message:message type:type];
            }
        }
    }];
}

- (void)actorFailed:(NSString *)path status:(int)status {
    [self dispatchOnActorQueue:^{
        NSMutableDictionary *requestInfo = self.activeRequests[path];
        if (requestInfo != nil) {
            Actor *requestActor = requestInfo[kRequestActor];
            
            NSMutableArray *pathSubscribers = requestInfo[kSubscribers];
            [self.activeRequests removeObjectForKey:path];
            for (ActionHandler *handler in pathSubscribers) {
                id<Subscriber> subscriber = handler.subscriber;
                if (subscriber != nil) {
                    if ([subscriber respondsToSelector:@selector(actorComplete:status:result:)]) {
                        [subscriber actorComplete:path status:status result:nil];
                    }
                    
                    if (handler.shouldReleaseOnMainQueue) {
                        dispatch_async(dispatch_get_main_queue(), ^{ [subscriber class]; });
                    }
                    subscriber = nil;
                }
            }
            [pathSubscribers removeAllObjects];
            
            if (requestActor == nil) {
                NSLog(@"[ActorModel] Warning: requestActor is nil");
            } else if (requestActor.queue != nil) {
                [self removeRequestActorFromQueue:requestActor.queue fromRequestActor:requestActor];
            }
        }
    }];
}

- (void)dispatchToPath:(NSString *)path progress:(CGFloat)progress {
    [self dispatchOnActorQueue:^{
        NSMutableDictionary *requestInfo = self.activeRequests[path];
        if (requestInfo == nil) {
            requestInfo = self.activeRequests[path];
        }
        
        if (requestInfo != nil) {
            NSMutableArray *subscribers = requestInfo[kSubscribers];
            for (ActionHandler *handler in subscribers) {
                id<Subscriber> subscriber = handler.subscriber;
                if (subscriber != nil) {
                    if ([subscriber respondsToSelector:@selector(receivePath:progress:)]) {
                        [subscriber receivePath:path progress:progress];
                    }
                    
                    if (handler.shouldReleaseOnMainQueue) {
                        dispatch_async(dispatch_get_main_queue(), ^{ [subscriber class]; });
                    }
                    subscriber = nil;
                }
            }
        }
    }];
}

- (void)scheduleCancelRequest:(NSString *)path {
    NSMutableDictionary *activeRequests = _activeRequests;
    NSMutableDictionary *cancelTimers = _cancelRequestTimers;
    
    NSMutableDictionary *requestInfo = activeRequests[path];
    NSMutableDictionary *cancelRequestInfo = cancelTimers[path];
    if (requestInfo != nil && cancelRequestInfo == nil) {
        Actor *requestActor = requestInfo[kRequestActor];
        NSTimeInterval cancelTimeout = requestActor.timeout;
        
        if (cancelTimeout <= DBL_EPSILON) {
            [activeRequests removeObjectForKey:path];
            
            [requestActor cancel];
            NSLog(@"[ActorModel] Cancelled request to \"%@\"", path);
            if (requestActor.queue != nil) {
                [self removeRequestActorFromQueue:requestActor.queue fromRequestActor:requestActor];
            }
        } else {
            NSLog(@"[ActorModel] Will cancel request to \"%@\" in %f s", path, cancelTimeout);
            NSDictionary *cancelDict = [NSDictionary dictionaryWithObjectsAndKeys:path, kPath, [NSNumber numberWithInt:0], @"type", nil];
            CustomTimer *timer = [[CustomTimer alloc] initWithTimeout:cancelTimeout repeat:false completion:^{
                [self performCancelRequest:cancelDict];
            } queue:[self serialActorDispatchQueue]];
            
            cancelRequestInfo = [[NSMutableDictionary alloc] initWithObjectsAndKeys:requestInfo, kRequestInfo, nil];
            cancelRequestInfo[kTimer] = timer;
            cancelTimers[path] = cancelRequestInfo;
            [activeRequests removeObjectForKey:path];
            
            [timer start];
        }
    } else if (cancelRequestInfo == nil) {
        NSLog(@"[ActorModel] Warning: cannot cancel request to \"%@\": no active request found", path);
    }
}
         
- (void)performCancelRequest:(NSDictionary *)cancelDict {
    NSString *path = cancelDict[kPath];
    
    [self dispatchOnActorQueue:^{
        NSMutableDictionary *cancelTimers = self.cancelRequestTimers;

        NSMutableDictionary *cancelRequestInfo = cancelTimers[path];
        if (cancelRequestInfo == nil) {
            NSLog(@"[ActorModel] Warning: cancelRequestTimerEvent: \"%@\": no cancel info found", path);
            return;
        }
        NSDictionary *requestInfo = cancelRequestInfo[kRequestInfo];
        Actor *requestActor = requestInfo[kRequestActor];
        if (requestActor == nil) {
            NSLog(@"[ActorModel] Warning: active request actor for \"%@\" not fond, cannot cancel request", path);
        } else {
            [requestActor cancel];
            NSLog(@"[ActorModel] Cancelled request to \"%@\"", path);
            if (requestActor.queue != nil) {
                [self removeRequestActorFromQueue:requestActor.queue fromRequestActor:requestActor];
            }
        }
        [cancelTimers removeObjectForKey:path];
    }];
}

@end
