//
//  Cancellable.h
//  ActorModel
//
//  Created by hanguang on 2020/5/21.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol Cancellable <NSObject>

@required

- (void)cancel;

@end
