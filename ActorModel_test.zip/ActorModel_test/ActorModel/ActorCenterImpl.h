//
//  GHActor.h
//  ActorModel
//
//  Created by hanguang on 2020/5/20.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <ActorModel/Subscriber.h>
#import <ActorModel/Actor.h>

#define PathParameterStartSymbol '('
#define PathParameterEndSymbol ')'
#define PathParameterSymbol '@'

typedef enum {
    ActorResultFailed = 100,
    ActorResultSuccess = 200,
} ActorResult;

#ifdef DEBUG
#define dispatchOnActorQueue dispatchOnActorQueueDebug:__FILE__ line:__LINE__ block
#endif

@class ActorCenterImpl;

#ifdef __cplusplus
extern "C" {
#endif

ActorCenterImpl *ActorCenter(void);

#ifdef __cplusplus
}
#endif

@interface ActorCenterImpl : NSObject

- (dispatch_queue_t)serialActorDispatchQueue;
#ifdef DEBUG
- (void)dispatchOnActorQueueDebug:(const char *)function line:(int)line block:(dispatch_block_t)block;
#else
- (void)dispatchOnActorQueue:(dispatch_block_t)block;
#endif

- (bool)isActorDispatchQueue;

// Common methods

- (NSString *)generateGenericPathForPath:(NSString *)path;
- (void)requestActor:(NSString *)path options:(NSDictionary *)options subscriber:(id<Subscriber>)subscriber;
- (void)requestActor:(NSString *)path options:(NSDictionary *)options subscriber:(id<Subscriber>)subscriber flags:(int)flags;

- (void)subscribePath:(NSString *)path subscriber:(id<Subscriber>)subscriber;
- (void)subscribePaths:(NSArray <NSString *> *)paths subscriber:(id<Subscriber>)subscriber;
- (void)subscribePath的genericPath:(NSString *)path subscriber:(id<Subscriber>)subscriber;

- (void)removeSubscriberByHandler:(ActionHandler *)handler;
- (void)removeSubscriber:(id<Subscriber>)subscriber;
- (void)removeSubscriberByHandler:(ActionHandler *)handler forPath:(NSString *)path;
- (void)removeSubscriber:(id<Subscriber>)subscriber forPath:(NSString *)path;
- (void)removeAllSubscriberForPath:(NSString *)path;

- (void)dispatchToPath:(NSString *)path resource:(id)resource;
- (void)dispatchToPath:(NSString *)path resource:(id)resource options:(NSDictionary *)options;
- (void)dispatchToPath:(NSString *)path progress:(CGFloat)progress;
- (void)dispatchToExecutingActors:(NSString *)path message:(id)message type:(NSString *)type;
- (void)dispatchToSubscriberPath:(NSString *)path message:(id)message type:(NSString *)type;

- (void)actorFailed:(NSString *)path status:(int)status;
- (void)actorComplete:(NSString *)path result:(id)result;

// Uncommon methods

- (void)cancelAllTimeoutActorForPath:(NSString *)path;

- (NSArray *)reSubscribeGenericPathForActorsNow:(NSString *)genericPath prefix:(NSString *)prefix subscriber:(id<Subscriber>)subscriber;

- (bool)isActorExecutingForGenericPath:(NSString *)genericPath;
- (bool)isActorExecutingForPathPrefix:(NSString *)prefix;
- (bool)isActorExecutingForPath:(NSString *)path;

- (NSArray <Actor *> *)executingActorsForPathPrefix:(NSString *)prefix;
- (Actor *)executingActorForPath:(NSString *)path;

#ifdef DEBUG
- (void)showActorCenterStatus;
#endif

@end
