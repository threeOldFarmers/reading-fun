//
//  CustomTimer.h
//  ActorModel
//
//  Created by hanguang on 2020/5/21.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomTimer : NSObject

- (instancetype)initWithTimeout:(NSTimeInterval)timeout repeat:(bool)repeat completion:(dispatch_block_t)completion queue:(dispatch_queue_t)queue;

- (void)start;
- (void)cancel;
- (void)startThenInvalid;

@end
