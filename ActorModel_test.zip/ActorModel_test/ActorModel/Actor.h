//
//  GHActor.h
//  ActorModel
//
//  Created by hanguang on 2020/5/21.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ActorModel/ActionHandler.h>

@protocol Cancellable;

@interface Actor : NSObject

+ (void)registerActor:(Class)actorClass;
+ (Actor *)actorClassForGenericPath:(NSString *)genericPath path:(NSString *)path;
+ (NSString *)genericPath;

@property (nonatomic, strong) NSString *path;
@property (nonatomic, strong) NSString *queue;
@property (nonatomic, strong) NSDictionary *storedOptions;

@property (nonatomic) NSTimeInterval timeout;
@property (nonatomic, strong) id<Cancellable> cancelToken;
@property (nonatomic, strong) NSMutableArray <id<Cancellable>> *cancelTokenArray;
@property (nonatomic) bool cancelled;

- (instancetype)initWithPath:(NSString *)path;
- (void)prepare:(NSDictionary *)options;
- (void)execute:(NSDictionary *)options;
- (void)cancel;

- (void)addCancelToken:(id<Cancellable>)token;

- (void)newSubscriberJoined:(ActionHandler *)actionHandler options:(NSDictionary *)options alreadyInQueue:(bool)alreadyInQueue;

@end
