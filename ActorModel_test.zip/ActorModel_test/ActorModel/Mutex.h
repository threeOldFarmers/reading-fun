//
//  Mutex.h
//  ActorModel
//
//  Created by hanguang on 2020/5/21.
//  Copyright © 2020 hanguang. All rights reserved.
//

#ifndef Mutex_h
#define Mutex_h

#import <pthread.h>

#define Mutex_Define(lock) pthread_mutex_t Mutex##lock
#define Mutex_Init(lock) pthread_mutex_init(&Mutex##lock, NULL)
#define Mutex_Lock(lock) pthread_mutex_lock(&Mutex##lock);
#define Mutex_Unlock(lock) pthread_mutex_unlock(&Mutex##lock);

#endif /* Mutex_h */
