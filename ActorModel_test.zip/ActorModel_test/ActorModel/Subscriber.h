//
//  Subscriber.h
//  ActorModel
//
//  Created by hanguang on 2020/5/20.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <ActorModel/ActionHandler.h>

@protocol Subscriber <NSObject>

@required

@property (nonatomic, strong, readonly) ActionHandler *handler;

@optional

- (void)receiveAction:(NSString *)action options:(NSDictionary *)options;
- (void)actorComplete:(NSString *)path status:(int)status result:(id)result;
- (void)receivePath:(NSString *)path progress:(CGFloat)progress;
- (void)receivePath:(NSString *)path resource:(id)resource options:(NSDictionary *)options;
- (void)receivePath:(NSString *)path message:(id)message type:(NSString *)type;

@end
