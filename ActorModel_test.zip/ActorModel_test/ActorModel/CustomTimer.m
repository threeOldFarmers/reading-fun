//
//  CustomTimer.m
//  ActorModel
//
//  Created by hanguang on 2020/5/21.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import "CustomTimer.h"

@implementation CustomTimer {
    dispatch_source_t _timer;
    NSTimeInterval _timeout;
    NSTimeInterval _timeoutDate;
    bool _repeat;
    dispatch_block_t _completion;
    dispatch_queue_t _queue;
}

- (instancetype)initWithTimeout:(NSTimeInterval)timeout repeat:(bool)repeat completion:(dispatch_block_t)completion queue:(dispatch_queue_t)queue {
    self = [super init];
    if (self != nil) {
        _timeoutDate = INT_MAX;
        _timeout = timeout;
        _repeat = repeat;
        _completion = [completion copy];
        _queue = queue;
    }
    return self;
}

- (void)dealloc {
    if (_timer != nil) {
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
}

- (void)start {
    _timeoutDate = CFAbsoluteTimeGetCurrent() + kCFAbsoluteTimeIntervalSince1970 + _timeout;
    
    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, _queue);
    dispatch_source_set_timer(_timer, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(_timeout * NSEC_PER_SEC)), _repeat ? (int64_t)(_timeout * NSEC_PER_SEC) : DISPATCH_TIME_FOREVER, 0);
    
    dispatch_source_set_event_handler(_timer, ^{
        if (self->_completion) {
            self->_completion();
        }
        if (!self->_repeat) {
            [self cancel];
        }
    });
    dispatch_resume(_timer);
}

- (void)startThenInvalid {
    if (_completion) {
        _completion();
    }
    [self cancel];
}

- (void)cancel {
    _timeoutDate = 0;
    
    if (_timer != nil) {
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
}

@end
