//
//  ActionHandler.m
//  ActorModel
//
//  Created by hanguang on 2020/5/20.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import "ActionHandler.h"
#import "Mutex.h"
#import "Subscriber.h"

@interface ActionHandler() {
    Mutex_Define(_subscriber);
}
@end

@implementation ActionHandler

@synthesize subscriber = _subscriber;

- (instancetype)initWithSubscriber:(id<Subscriber>)subscriber {
    return [self initWithSubscriber:subscriber shouldReleaseOnMainQueue:true];
}

- (instancetype)initWithSubscriber:(id<Subscriber>)subscriber shouldReleaseOnMainQueue:(bool)shouldReleaseOnMainQueue {
    self = [super init];
    if (self != nil) {
        Mutex_Init(_subscriber);
        _subscriber = subscriber;
        _shouldReleaseOnMainQueue = shouldReleaseOnMainQueue;
    }
    return self;
}

- (void)reset {
    Mutex_Lock(_subscriber);
    _subscriber = nil;
    Mutex_Unlock(_subscriber);
}

- (bool)isHaveSubscriber {
    bool result = false;
    
    Mutex_Lock(_subscriber);
    result = _subscriber != nil;
    Mutex_Unlock(_subscriber);
    
    return result;
}

- (id<Subscriber>)subscriber {
    id<Subscriber> result = nil;
    
    Mutex_Lock(_subscriber);
    result = _subscriber;
    Mutex_Unlock(_subscriber);
    
    return result;
}

- (void)setsubscriber:(id<Subscriber>)subscriber {
    Mutex_Lock(_subscriber);
    _subscriber = subscriber;
    Mutex_Unlock(_subscriber);
}

- (void)notifyActionReceived:(NSString *)action options:(NSDictionary *)options {
    __strong id<Subscriber> subscriber = self.subscriber;
    if (subscriber != nil && [subscriber respondsToSelector:@selector(receiveAction:options:)]) {
        [subscriber receiveAction:action options:options];
    }
    
    if (_shouldReleaseOnMainQueue && ![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [subscriber class];
        });
    }
}

- (void)notifyMessageReceived:(NSString *)path message:(id)message type:(NSString *)type {
    __strong id<Subscriber> subscriber = self.subscriber;
    if (subscriber != nil && [subscriber respondsToSelector:@selector(receivePath:message:type:)]) {
        [subscriber receivePath:path message:message type:type];
    }
    
    if (_shouldReleaseOnMainQueue && ![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [subscriber class];
        });
    }
}

- (void)notifyResourceReceived:(NSString *)path resource:(id)resource options:(NSDictionary *)options {
    __strong id<Subscriber> subscriber = self.subscriber;
    if (subscriber != nil && [subscriber respondsToSelector:@selector(receivePath:resource:options:)]) {
        [subscriber receivePath:path resource:resource options:options];
    }
    
    if (_shouldReleaseOnMainQueue && ![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [subscriber class];
        });
    }
}

@end
