//
//  Diffable.h
//  example
//
//  Created by guang.a.han on 2020/6/23.
//  Copyright © 2020 LawrenceHan. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol Diffable

- (nonnull id<NSObject>)diffIdentifier;
- (BOOL)isEqualToDiffableObject:(nullable id<Diffable>)object;

@end
