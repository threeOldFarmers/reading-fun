//
//  UpdateUserName.m
//  example
//
//  Created by hanguang on 2020/5/25.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import "更新用户名Actor.h"
#import "HttpClient.h"

@implementation 更新用户名Actor

+ (void)load {
    [Actor registerActor:self];
}

+ (NSString *)genericPath {
    return @"用户/更新用户名";
}

- (void)prepare:(NSDictionary *)options {
}

- (void)execute:(NSDictionary *)options {
    NSString *url = options[@"url"];
    NSString *username = options[@"用户名"];
    
    if (url.length) {
        self.cancelToken = [HttpClient requestWith:url completion:^{
            [ActorCenter() actorComplete:self.path result:nil];
            [ActorCenter() requestActor:@"首页/用户名" options:@{@"用户名": username} subscriber:[HttpClient instance]];
        }];
    } else {
        [ActorCenter() actorFailed:self.path status:ActorResultFailed];
    }
}

- (void)dealloc {
    NSLog(@"更新用户名Actor: dealloc");
}

@end
