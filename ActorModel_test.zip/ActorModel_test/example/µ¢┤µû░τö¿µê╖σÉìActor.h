//
//  UpdateUserName.h
//  example
//
//  Created by hanguang on 2020/5/25.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ActorModel/ActorModel.h>

@interface 更新用户名Actor : Actor

@end
