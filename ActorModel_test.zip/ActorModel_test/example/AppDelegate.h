//
//  AppDelegate.h
//  example
//
//  Created by hanguang on 2020/5/22.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

