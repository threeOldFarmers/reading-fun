//
//  ViewController.m
//  example
//
//  Created by hanguang on 2020/5/22.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import "ViewController.h"
#import <ActorModel/ActorModel.h>
#import "HttpClient.h"

@interface ViewController () <Subscriber>

@property (nonatomic, strong) ActionHandler *handler;
@property (nonatomic, strong) NSString *username;
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UITextField *textfield;
@property (weak, nonatomic) IBOutlet UIButton *changeNameButton;
@property (weak, nonatomic) IBOutlet UILabel *消息Label;

@property (nonatomic, strong) NSArray *test;
@property (nonatomic, strong) NSDictionary *temp;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _handler = [[ActionHandler alloc] initWithSubscriber:self];
    
    [ActorCenter() subscribePath:@"首页/用户名" subscriber:self];
    [ActorCenter() subscribePath:@"消息/hello" subscriber:self];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(隐藏键盘)];
    [self.view addGestureRecognizer:tap];
    
    _temp = @{@"key": @1, @"key2": @3};
    
    NSArray *test1 = @[@1];
    NSArray *test2 = @[];
    NSArray *test3 = nil;
    
    bool result1 = [_test isEqual:test1];
    bool result2 = [_test isEqual:test2];
    bool result3 = [_test isEqual:test3];
    
    NSLog(@"result1: %@, result2: %@, result3: %@", result1 ? @"true" : @"false", result2 ? @"true" : @"false", result3 ? @"true" : @"false");
    
    NSDictionary *temp1 = @{@"key": @1};
    NSDictionary *temp2 = @{};
    NSDictionary *temp3 = @{@"key": @1, @"key2": @3};
    
    bool result4 = [_temp isEqual:temp1];
    bool result5 = [_temp isEqual:temp2];
    bool result6 = [_temp isEqual:temp3];
    
    NSLog(@"temp1: %@, temp2: %@, temp3: %@", result4 ? @"true" : @"false", result5 ? @"true" : @"false", result6 ? @"true" : @"false");
}

- (void)dealloc {
    [_handler reset];
    [ActorCenter() removeSubscriber:self];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [ActorCenter() requestActor:@"首页/用户名" options:nil subscriber:[HttpClient instance]];
}


- (void)updateUI {
    _label.text = _username;
}

- (IBAction)changeUsernameTouched:(UIButton *)sender {
    if (_textfield.text.length) {
        [ActorCenter() requestActor:@"用户/更新用户名" options:@{@"url": @"text/updateusername", @"用户名": _textfield.text} subscriber:[HttpClient instance]];
        _textfield.text = @"";
    } else {
        NSLog(@"名称长度为0");
    }
}

- (void)隐藏键盘 {
    [_textfield endEditing:true];
}

- (void)receivePath:(NSString *)path resource:(id)resource options:(NSDictionary *)options {
    if ([path isEqualToString:@"首页/用户名"]) {
        NSLog(@"received resource on actor queue");
        __weak __typeof(self)weakSelf = self;
        DispatchOnMainQueue(^{
            NSLog(@"update UI on main queue");
            __strong __typeof(weakSelf)strongSelf = weakSelf;
            if (strongSelf != nil) {
                strongSelf.username = (NSString *)resource;
                [strongSelf updateUI];
            }
        });
    }
}

- (void)receivePath:(NSString *)path message:(id)message type:(NSString *)type {
    if ([path isEqualToString:@"消息/hello"]) {
        __weak __typeof(self)weakSelf = self;
        DispatchOnMainQueue(^{
            __strong __typeof(weakSelf)strongSelf = weakSelf;
            if (strongSelf != nil) {
                NSString *text = (NSString *)message;
                strongSelf.消息Label.text = text.length > 0 ? text : @"";
            }
        });
    }
}

@end
