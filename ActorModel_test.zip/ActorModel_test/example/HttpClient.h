//
//  HttpClient.h
//  example
//
//  Created by hanguang on 2020/5/22.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "获取用户名Actor.h"

@interface CancelObject : NSObject <Cancellable>

@end

@interface HttpClient : NSObject <Subscriber>

+ (HttpClient *)instance;

+ (CancelObject *)requestWith:(NSString *)url actor:(Actor *)actor;
+ (CancelObject *)requestWith:(NSString *)url completion:(void (^)(void))completion;

@end
