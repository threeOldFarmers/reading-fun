//
//  TestActor.m
//  example
//
//  Created by hanguang on 2020/5/22.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import "获取用户名Actor.h"
#import "HttpClient.h"

@implementation 获取用户名Actor {
    NSString *_用户名;
}

+ (void)load {
    [Actor registerActor:self];
}

+ (NSString *)genericPath {
    return @"首页/用户名";
}

- (void)prepare:(NSDictionary *)options {
    NSLog(@"actor prepare，可以在这个阶段为execute prepare一些参数。此时线程已经切换到ActorQueue");
    _用户名 = @"韩光";
}

- (void)execute:(NSDictionary *)options {
    NSLog(@"actor 开始execute");
    
    // now running on http client queue
    NSString *用户名 = options[@"用户名"];
    if (用户名.length) {
        _用户名 = 用户名;
    }
    self.cancelToken = [HttpClient requestWith:@"test/getusername" actor:self];
}

- (void)httpRequestSuccess:(NSString *)url response:(NSData *)response {
    NSLog(@"网络请求成功后回到actor queue");
    
    [ActorCenter() dispatchToPath:self.path resource:_用户名];
    [ActorCenter() actorComplete:self.path result:nil];
}

- (void)httpRequestFailed:(NSString *)url {
    [ActorCenter() actorFailed:self.path status:ActorResultFailed];
}

- (void)dealloc {
    NSLog(@"获取用户名Actor: dealloc");
}

@end
