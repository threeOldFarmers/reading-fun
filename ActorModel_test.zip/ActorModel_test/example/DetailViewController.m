//
//  DetailViewController.m
//  example
//
//  Created by hanguang on 2020/5/25.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import "DetailViewController.h"
#import <ActorModel/ActorModel.h>

@interface DetailViewController () <Subscriber>

@property (nonatomic, strong) ActionHandler *handler;

@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UILabel *消息Label;

@end

@implementation DetailViewController

- (void)dealloc {
    [_handler reset];
    [ActorCenter() removeSubscriber:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _handler = [[ActionHandler alloc] initWithSubscriber:self];
    
    [ActorCenter() subscribePath:@"消息/hello" subscriber:self];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(隐藏键盘)];
    [self.view addGestureRecognizer:tap];
}

- (IBAction)发送消息点击:(UIButton *)sender {
    [ActorCenter() dispatchToSubscriberPath:@"消息/hello" message:_textField.text type:nil];
}

- (void)隐藏键盘 {
    [_textField endEditing:true];
}

- (void)receivePath:(NSString *)path message:(id)message type:(NSString *)type {
    if ([path isEqualToString:@"消息/hello"]) {
        __weak __typeof(self)weakSelf = self;
        DispatchOnMainQueue(^{
            __strong __typeof(weakSelf)strongSelf = weakSelf;
            if (strongSelf != nil) {
                NSString *text = (NSString *)message;
                strongSelf.消息Label.text = text.length > 0 ? text : @"";
            }
        });
    }
}

@end
