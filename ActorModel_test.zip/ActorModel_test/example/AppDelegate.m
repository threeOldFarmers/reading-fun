//
//  AppDelegate.m
//  example
//
//  Created by hanguang on 2020/5/22.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import "AppDelegate.h"
#import "Diffable.h"

@interface TestObject : NSObject <Diffable>

@property (nonatomic, strong) NSString *name;

@end

@implementation TestObject

- (id<NSObject>)diffIdentifier {
    return @"TestObject";
}

- (BOOL)isEqualToDiffableObject:(id)object {
    if (object == self) {
        return YES;
    }
    
    if ([object isKindOfClass:[TestObject class]]) {
        TestObject *other = object;
        return [self.name isEqual:other.name];
    }
    
    return NO;
}

@end

@interface AppDelegate ()

@property (nonatomic, strong) TestObject *lastData;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    NSDate *DBMaxDay;
    NSCalendar *calendar = [NSCalendar currentCalendar];
//    [calendar setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    NSDateComponents *comps = nil;    //DTS2014101007072 deleted by s00208950 20141011
    NSInteger unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth |NSCalendarUnitDay | NSCalendarUnitWeekday | NSCalendarUnitHour | NSCalendarUnitMinute |NSCalendarUnitSecond;
    
    comps = [calendar components:unitFlags fromDate:[NSDate date]];
    
    [comps setHour:0];
    [comps setMinute:0];
    [comps setSecond:0];
    DBMaxDay = [calendar dateFromComponents:comps];
    
    TestObject *t1 = [TestObject new];
    t1.name = @"test1";
    
    _lastData = [TestObject new];
    _lastData.name = @"test 1";
    bool result1 = [self diff:nil];
    NSLog(@"result1: %@", result1 ? @"true" : @"false");
    
    NSNumber *n1 = @(7.981172312);
    NSNumber *n2 = @(7.5);
    NSNumber *n3 = @(7.4);
    NSNumber *n4 = @(7.0);
    
    NSLog(@"number 1: %ld, number 2: %ld, number 3: %ld, number 4: %ld", n1.integerValue, n2.integerValue, n3.integerValue, n4.integerValue);
    
    return YES;
}

- (bool)diff:(TestObject *)data {
    if (_lastData == nil && data == nil) {
        return true;
    }
    return [_lastData isEqualToDiffableObject:data];
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
