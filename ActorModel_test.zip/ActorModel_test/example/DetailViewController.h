//
//  DetailViewController.h
//  example
//
//  Created by hanguang on 2020/5/25.
//  Copyright © 2020 hanguang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@end
