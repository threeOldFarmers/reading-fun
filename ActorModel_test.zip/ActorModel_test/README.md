# Actor
Objective-C Actor 中文版

中文编程的第一次尝试，使用中文去命名变量和方法。欢迎来玩。
